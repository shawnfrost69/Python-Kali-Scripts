---
name: General question
about: Ask some general question
title: ''
labels: ''
assignees: ''

---

<!--- Please, consider to contact us on Discord or IRC before opening an issue. More info and Discord invitation link here: https://github.com/v1s1t0r1sh3r3/airgeddon/wiki/Contact -->
<!--- Did you read the FAQ & Troubleshooting wiki section before asking? Maybe the answer is there: https://github.com/v1s1t0r1sh3r3/airgeddon/wiki/FAQ%20&%20Troubleshooting -->
<!--- Answer the questions to provide maximum of info -->
<!--- Filling this issue template is mandatory. Otherwise the issue can be directly closed -->
<!--- Write in English only -->
<!--- If additional info is required and requested by airgeddon's staff, you have 7 days to respond, otherwise the issue will be closed -->
<!--- Read the Issue Creation Policy on Contributing section before creating the issue -->

#### Is your question related to any concrete technology?

<!--- Insert answer here, e.g. Linux, Docker, Wireless -->

#### Describe your question as detailed as possible

<!--- Insert answer here -->
